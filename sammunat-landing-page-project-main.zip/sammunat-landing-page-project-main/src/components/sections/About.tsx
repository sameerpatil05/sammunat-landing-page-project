const About = () => {
  return (
    <section id="about" className="py-20 bg-secondary/50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
            About Sammunat
          </h2>
          
          <p className="text-lg text-muted-foreground leading-relaxed">
            At Sammunat, we believe in the power of technology to transform businesses. 
            As a forward-thinking startup, we combine innovation with trust to deliver 
            scalable solutions that drive real results. Our team of dedicated professionals 
            works closely with clients to understand their unique challenges and craft 
            customized strategies that fuel sustainable growth in today's digital landscape.
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;
