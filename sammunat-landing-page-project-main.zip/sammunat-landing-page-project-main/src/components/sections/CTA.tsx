import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const CTA = () => {
  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center bg-primary rounded-2xl p-10 md:p-14">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
            Ready to Start Your Journey?
          </h2>
          <p className="text-lg text-primary-foreground/90 mb-8">
            Connect with us today and discover how Sammunat can help transform your business 
            with cutting-edge digital solutions.
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            className="gap-2"
          >
            Get in Touch
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CTA;
